1.   Masuk ke halaman login.html
2.   Akan muncul halaman dengan hak akses HR Staff
3.1  Jika klik menu penggajian akan masuk ke menu dengan hak akses karyawan
3.2 Jika klik logout akan kembali ke halaman login